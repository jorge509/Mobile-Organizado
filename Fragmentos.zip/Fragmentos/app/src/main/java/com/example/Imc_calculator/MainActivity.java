package com.example.Imc_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Button btn1;
    private EditText Imc;

    private EditText pesso;
    private EditText altura;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = (Button) findViewById(R.id.btn1);
        pesso = (EditText) findViewById(R.id.pesso);
        altura = (EditText) findViewById(R.id.altura);
        Imc=(EditText) findViewById(R.id.imc);


        btn1.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                double peso = Double.parseDouble(pesso.getText().toString());
                double altur = Double.parseDouble(altura.getText().toString());
                double imc = (peso/Math.pow(altur,2)) ;
                String p = String.valueOf(Math.round(imc));
                Imc.setText(p);

           if(Math.round(imc)>=31){
               Toast.makeText(getApplicationContext(),"Estas gordo urgente a un gym",Toast.LENGTH_SHORT).show();
           }
           else{
               Toast.makeText(getApplicationContext(),"Estas excelente saludos!!",Toast.LENGTH_SHORT).show();

           }
            }
        });
    }

    @Override
    public void onClick(View view) {

    }
}

