package com;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.todos_en_uno.R;

public class Actividad_principal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_principal2);
    }
}