package com.example.classic;

import android.app.Activity;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;

public class correr extends Activity {
    protected static final String TAG = "filtrao";

    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        Log.i(TAG, "Oncreate chamado");
    }
    protected void OnRestart(){
        super.onRestart();
        Log.i(TAG,"OnCreate chamado");

    }

    protected void OnReume(){
        Log.i(TAG,"OnResume chamado");

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG,"OnPause chamado");
    }

    @Override
    protected void onSaveInstanceState( Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i(TAG,"OnSaveInstance chamado");
    }
    protected void onStop() {
        Log.i(TAG,"OnStop chamado");
        super.onStop();
    }
}