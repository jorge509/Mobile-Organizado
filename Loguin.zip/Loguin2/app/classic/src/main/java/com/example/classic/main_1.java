package com.example.classic;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class main_1 extends AppCompatActivity {
    private EditText usuario;
    private EditText seña;
    private Button bt1;
    private Button btn2;
    private String dados;
    private String Nombre;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usuario = (EditText) findViewById(R.id.usuario);
        seña = (EditText) findViewById(R.id.seña);
        bt1 = (Button) findViewById(R.id.btn);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if
                (usuario.getText().toString().equals("usuario") && seña.getText().toString().equals("123")) {
                    Intent intent = new Intent(getApplicationContext(), bonjour.class);
                    Bundle params=new Bundle();
                    params.putString("Nombre",Nombre);
                    intent.putExtras(params);
                    startActivity(intent);



                } else {
                    Toast.makeText(getApplicationContext(), "dados incorrectos", Toast.LENGTH_LONG).show();
                }


            }
        });
    }


    protected void onSaveInstanceState(Bundle dados) {
        super.onSaveInstanceState(dados);
        dados.putString("chavedados", String.valueOf(dados));
    }

}
