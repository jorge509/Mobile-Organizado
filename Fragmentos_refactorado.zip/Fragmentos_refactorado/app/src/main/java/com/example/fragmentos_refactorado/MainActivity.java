package com.example.fragmentos_refactorado;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

    public class MainActivity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            ActionBar actionBar=getSupportActionBar();
            actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

            ActionBar.Tab tab1=actionBar.newTab().setText("Frag1");
            tab1.setTabListener(new MyTabListener(new Fragment1()));
            actionBar.addTab(tab1);


            ActionBar.Tab tab2=actionBar.newTab().setText("Frag2");
            tab2.setTabListener(new MyTabListener(new com.example.fragmentos_refactorado.Fragment2()));
            actionBar.addTab(tab2);
        /*
       if(savedInstanceState==null){
           FragmentManager f=getSupportFragmentManager();
           FragmentTransaction ft=f.beginTransaction();
           Fragment1 frag1=new Fragment1();
           ft.add(R.id.layoutFrag,frag1,null);
           ft.commit();

*/


            // }

        }
    }