package com.example.aulasqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class pessoadb  extends SQLiteOpenHelper {
private static final String TAG="sql";
private static final String NOME_BANCO="pessoa.sqLite";
private static final int VERSAO=1;

    public pessoadb(Context context) {
        super(context, "pessoa.sqlite", null, 1);
    }
    public long save(pessoa p) {
        long id = p.getId();
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("nome", p.getNome());
            values.put("curso", p.getCurso());
            if (id != 0) {
//actualizar
                String _id = String.valueOf(p.getId());
                String[] args = new String[]{_id};
                int count = db.update("pessoa", values, "_id=?", args);
                return count;
            } else {
                //insertart
                id = db.insert("pessoa", null, values);
                return id;
            }
        } finally {
            db.close();
        }

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Log.d(TAG,"criando a tabela pessoa");
        sqLiteDatabase.execSQL("create table if not exists pessoa(_id integer primary key autoincrement,nome text, curso text)");
        Log.d(TAG, "tabela criada");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    @SuppressLint("Range")
    public List<pessoa> findAll() {
        SQLiteDatabase db = getWritableDatabase();
        try {
            Cursor c = db.rawQuery("select * from pessoa ", null);
            return toList(c);
        } finally {
            db.close();
        }
    }

    @SuppressLint("Range")
    private List<pessoa>toList(Cursor c) {
        List<pessoa> pessoas = new ArrayList<>();
        if (c.moveToFirst()) {
            do {
                pessoa p = new pessoa();
                p.setId(c.getInt(c.getColumnIndex("_id")));
                p.setNome(c.getString(c.getColumnIndex("nome")));
                p.setCurso(c.getString(c.getColumnIndex("Curso")));
                pessoas.add(p);

            } while (c.moveToNext());
        }
        return pessoas;

    }
}